﻿namespace Water2D{
    using UnityEngine;
    using UnityEngine.Events;
    using System.Collections;
    using System;
    
    [Serializable]
    public class Water2DEvents : UnityEvent<GameObject, GameObject>{}
   

}