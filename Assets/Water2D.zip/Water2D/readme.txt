Water 2D Unity Asset 

Water 2D it's a better way to render 2D interactable fluid water particles in Unity. 

Details:
Water 2D uses Metaballs to render each particle in front of the camera and obtains the physical properties of the RigidBody2D
for simulate the physics of movements and collisions.

Import this asset and start making fantastic water games titles as "Where is my water", "Happy Glass" or "Dig Caves".

Features:
- Mobile friendly
- Excelent for games or simulation purposes a CPU cheap cost.
- Oddly satisfying water flow effect.
- Interactable with the environment.
- It comes with very easy a handmade ParticleSystem to control the position, speed and color of the water.
- It comes with Prefabs to easily Scenes setup.
- Inspector is very easy to understand, so you won't need a tutorial or guide.
- Doesn't need Unity Pro
- Doesn't need advance knowledge in coding.


If you have questions or issues, please reach me out at: info@2ddlpro.com, I will answer ASAP.

Check out my other assets: 
